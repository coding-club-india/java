package memory.folder.controlStatement;

public class q12 
{
    // write a program to input a month number and print month name
 public static void main(String[] args) 
 { 
    int num = 1;
    if(num == 1)
    {
           System.out.println( num +" is a junuary month");
    }
    else if(num == 2)
    {
           System.out.println( num +" is a febary month");
    }
    else if(num == 3)
    {
           System.out.println( num +" is a march month");
    }
     else if(num == 4)
    {
           System.out.println( num +" is a april month");
    }
    else if(num == 5)
    {
           System.out.println( num +" is a may month");
    }
    else if(num == 6)
    {
           System.out.println( num +" is a june month");
    }
    else if(num == 7)
    {
           System.out.println( num +" is a july month");
    }
    else if(num == 8)
    {
           System.out.println( num +" is a august month");
    }
    else if(num == 9)
    {
           System.out.println( num +" is a september month");
    }
    else if(num == 10)
    {
           System.out.println( num +" is a october month");
    }
    else if(num == 11)
    {
           System.out.println( num +" is a november month");
    }
    else if(num == 12)
    {
           System.out.println( num +" is a dicember month");
    }
    else
    {
           System.out.println( num +" is not a valid month number");
           System.out.println(" Please write a valid month number");
    }
    
    
 }   
}
