package memory.folder.controlStatement;

public class q11 
{
    // write a program  to input week number ANd print week day.
   public static void main(String[] args) 
   {
    int num =7;
    if(num==1){
        System.out.println(num +" is a sunday");
    }else if(num==2){
        System.out.println(num +" is a sunday");
    }
    else if(num==3){
        System.out.println(num +" is a sunday");
    }
    else if(num==4){
        System.out.println(num +" is a sunday");
    }
    else if(num==5){
        System.out.println(num +" is a sunday");
    }
    else if(num==6) {
        System.out.println(num +" is a sunday");
    }else if(num==7){
        System.out.println(num +" is a sunday");
    }else{
        System.out.println(num +" is not a valid number");
        System.out.println("Please write a valid number");
    } } }
