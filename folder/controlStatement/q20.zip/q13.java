package memory.folder.controlStatement;

public class q13 

{
    // write a program to count total no. of  notes in given ammount.
    public static void main(String[] args) 
    {
        int num= 3;
        if()
        {

        }
        
    }
    
}
