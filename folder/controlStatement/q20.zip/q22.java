package memory.folder.controlStatement;

public class q22 
{
    // while purchasing certain items, a discount  of 10% is offered if the quantity purchased is more than 100. 
   // if quantity and price per item are input through the keybopard,write a program to calculate the total expenses
    public static void main(String[] args) 
    {
      if()  
    }
    
}
