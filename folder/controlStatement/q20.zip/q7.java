package memory.folder.controlStatement;

public class q7 
{
    // write a program to check whether charACTER is alphabet or not.
    public static void main(String[] args) 
    {
        char num = '1';
        if((num>='a'&& num<='z')||(num>='A'&&num<='Z') )
        {
            System.out.println(num +" is  a character");

        }
        else
        {
             System.out.println(num +" is  not a character");

        }
        String x =(num>='a'&& num<='z')||(num>='A'&&num<='Z') ?(num +" is  a character"):(num +" is  not a character");
    System.out.println(x);
    }
    
}
